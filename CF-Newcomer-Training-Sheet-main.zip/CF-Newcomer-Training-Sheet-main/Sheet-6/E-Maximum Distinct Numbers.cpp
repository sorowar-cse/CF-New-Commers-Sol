#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    long long int n, x;
    cin >> n;
    x = ((-1 + sqrt(8 * n + 1)) / 2);
    cout << x;
}
